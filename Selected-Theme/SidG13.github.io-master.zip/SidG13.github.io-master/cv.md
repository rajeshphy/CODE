---
title: CV
layout: cv
actions:
  - label: "Download full CV"
    icon: pdf
    url: "assets/files/SSG_CV_2024.06.16.pdf"
---